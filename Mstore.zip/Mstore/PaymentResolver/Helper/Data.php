<?php declare(strict_types=1);

namespace Mstore\PaymentResolver\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{

}
