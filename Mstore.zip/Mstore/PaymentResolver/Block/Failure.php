<?php declare(strict_types=1);

namespace Mstore\PaymentResolver\Block;

use Magento\Framework\View\Element\Template;

class Failure extends Template
{
}
